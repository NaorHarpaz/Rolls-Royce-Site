/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        gold: {
          50: '#fbf8f1',
          100: '#f7f1e1',
          200: '#eee0b5',
          300: '#e5cb89',
          400: '#dcb65d',
          500: '#d4a131',
          600: '#c08828',
          700: '#a06b24',
          800: '#815524',
          900: '#6b4620',
          950: '#3b2611',
        },
      },
      boxShadow: {
        'inner-gold': 'inset 0 2px 4px 0 rgba(212, 161, 49, 0.2)',
      },
    },
  },
  plugins: [],
};