export interface Car {
  id: string;
  name: string;
  img: string;
  desc: string;
  longDesc: string;
  price: string;
}

export type CarsData = Record<string, Car>;

export interface OrderFormData {
  firstName: string;
  lastName: string;
}