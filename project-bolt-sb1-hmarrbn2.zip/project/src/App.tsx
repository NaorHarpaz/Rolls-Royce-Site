import React, { useState } from 'react';
import Header from './components/Header';
import CarList from './components/CarList';
import CarDetails from './components/CarDetails';
import OrderForm from './components/OrderForm';
import { cars } from './data/cars';
import { OrderFormData } from './types';

function App() {
  const [selectedCarId, setSelectedCarId] = useState<string | null>(null);
  const [showOrderForm, setShowOrderForm] = useState(false);
  
  const handleShowDetails = (id: string) => {
    setSelectedCarId(id);
    setShowOrderForm(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  const handleBack = () => {
    setSelectedCarId(null);
    setShowOrderForm(false);
  };

  const handleOrder = () => {
    setShowOrderForm(true);
  };

  const handleOrderSubmit = (data: OrderFormData) => {
    console.log('Order submitted:', { car: selectedCarId, ...data });
    setSelectedCarId(null);
    setShowOrderForm(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white" dir="rtl">
      <Header />
      <main className="container mx-auto py-8 px-4">
        {showOrderForm && selectedCarId ? (
          <OrderForm
            carName={cars[selectedCarId].name}
            onBack={handleBack}
            onSubmit={handleOrderSubmit}
          />
        ) : selectedCarId ? (
          <CarDetails
            car={cars[selectedCarId]}
            onBack={handleBack}
            onOrder={handleOrder}
          />
        ) : (
          <CarList cars={cars} onShowDetails={handleShowDetails} />
        )}
      </main>
    </div>
  );
}

export default App;