import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="flex justify-between items-center bg-black py-4 px-8 relative border-b border-gold-600/20">
      <h1 className="text-2xl md:text-3xl font-bold text-white order-2">Rolls Royce Sallon</h1>
      <img 
        src="https://i.imgur.com/edItsku.png" 
        alt="לוגו רולס רויס" 
        className="absolute left-1/2 transform -translate-x-1/2 h-16 w-auto"
      />
    </header>
  );
};

export default Header;