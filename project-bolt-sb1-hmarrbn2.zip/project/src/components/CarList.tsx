import React from 'react';
import CarCard from './CarCard';
import { CarsData } from '../types';

interface CarListProps {
  cars: CarsData;
  onShowDetails: (id: string) => void;
}

const CarList: React.FC<CarListProps> = ({ cars, onShowDetails }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 p-8">
      {Object.values(cars).map((car) => (
        <CarCard key={car.id} car={car} onShowDetails={onShowDetails} />
      ))}
    </div>
  );
};

export default CarList;