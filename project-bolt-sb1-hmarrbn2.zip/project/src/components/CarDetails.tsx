import React from 'react';
import { Car } from '../types';

interface CarDetailsProps {
  car: Car;
  onBack: () => void;
  onOrder: () => void;
}

const CarDetails: React.FC<CarDetailsProps> = ({ car, onBack, onOrder }) => {
  return (
    <div className="max-w-2xl mx-auto bg-black rounded-xl shadow-lg shadow-white/20 p-6 animate-fadeIn">
      <h2 className="text-2xl font-bold text-white mb-4">{car.name}</h2>
      <div className="overflow-hidden rounded-xl mb-6">
        <img 
          src={car.img} 
          alt={car.name} 
          className="w-full h-auto rounded-xl"
        />
      </div>
      <p className="text-white text-lg leading-relaxed mb-6 text-right">{car.longDesc}</p>
      <p className="text-white text-xl font-bold mb-8 text-right">מחיר: {car.price}</p>
      
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <button 
          onClick={onBack}
          className="flex-1 bg-black text-white border border-white/70 rounded-lg py-3 px-6 font-semibold 
                    hover:bg-white hover:text-black transition-all duration-300 
                    shadow-md hover:shadow-white/30"
        >
          חזרה
        </button>
        <button 
          onClick={onOrder}
          className="flex-1 bg-gradient-to-r from-gray-700 to-gray-900 text-white border border-white/20 rounded-lg py-3 px-6 font-semibold 
                    hover:from-white hover:to-gray-200 hover:text-black transition-all duration-300 
                    shadow-md hover:shadow-white/30"
        >
          הזמן עכשיו
        </button>
      </div>
    </div>
  );
};

export default CarDetails;