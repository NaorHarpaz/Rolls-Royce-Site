import React, { useState } from 'react';
import { OrderFormData } from '../types';

interface OrderFormProps {
  carName: string;
  onBack: () => void;
  onSubmit: (data: OrderFormData) => void;
}

const OrderForm: React.FC<OrderFormProps> = ({ carName, onBack, onSubmit }) => {
  const [formData, setFormData] = useState<OrderFormData>({
    firstName: '',
    lastName: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="max-w-md mx-auto bg-black rounded-xl shadow-lg shadow-white/20 p-6 animate-fadeIn">
      <h2 className="text-2xl font-bold text-white mb-6 text-center">הזמנת {carName}</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="firstName" className="block text-white text-right mb-2">שם פרטי</label>
          <input
            type="text"
            id="firstName"
            value={formData.firstName}
            onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
            className="w-full bg-gray-900 text-white border border-white/30 rounded-lg p-2 focus:outline-none focus:border-white"
            required
          />
        </div>
        
        <div>
          <label htmlFor="lastName" className="block text-white text-right mb-2">שם משפחה</label>
          <input
            type="text"
            id="lastName"
            value={formData.lastName}
            onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
            className="w-full bg-gray-900 text-white border border-white/30 rounded-lg p-2 focus:outline-none focus:border-white"
            required
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-4 pt-4">
          <button
            type="button"
            onClick={onBack}
            className="flex-1 bg-black text-white border border-white/70 rounded-lg py-3 px-6 font-semibold 
                      hover:bg-white hover:text-black transition-all duration-300 
                      shadow-md hover:shadow-white/30"
          >
            חזרה
          </button>
          <button
            type="submit"
            className="flex-1 bg-gradient-to-r from-gray-700 to-gray-900 text-white border border-white/20 rounded-lg py-3 px-6 font-semibold 
                      hover:from-white hover:to-gray-200 hover:text-black transition-all duration-300 
                      shadow-md hover:shadow-white/30"
          >
            הזמן עכשיו
          </button>
        </div>
      </form>
    </div>
  );
};

export default OrderForm;