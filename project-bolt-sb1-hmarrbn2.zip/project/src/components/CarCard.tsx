import React from 'react';
import { Car } from '../types';

interface CarCardProps {
  car: Car;
  onShowDetails: (id: string) => void;
}

const CarCard: React.FC<CarCardProps> = ({ car, onShowDetails }) => {
  return (
    <div className="bg-black rounded-xl shadow-lg shadow-white/10 hover:shadow-white/20 transition-all duration-300 p-4 flex flex-col items-center">
      <div className="overflow-hidden rounded-lg mb-4 w-full">
        <img 
          src={car.img} 
          alt={car.name} 
          className="w-full h-56 object-cover rounded-lg transition-transform duration-700 hover:scale-105"
        />
      </div>
      <h2 className="text-xl font-bold text-white mb-2">{car.name}</h2>
      <p className="text-white text-center flex-grow mb-4">{car.desc}</p>
      <button 
        onClick={() => onShowDetails(car.id)}
        className="w-full bg-black text-white border border-white/70 rounded-lg py-2 px-6 font-semibold 
                   hover:bg-white hover:text-black transition-all duration-300 
                   shadow-md hover:shadow-white/30 transform hover:-translate-y-1"
      >
        פרטים
      </button>
    </div>
  );
};

export default CarCard;