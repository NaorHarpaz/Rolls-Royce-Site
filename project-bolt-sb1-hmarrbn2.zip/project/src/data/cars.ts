import { CarsData } from '../types';

export const cars: CarsData = {
  phantom: {
    id: 'phantom',
    name: "Phantom",
    img: "https://hips.hearstapps.com/hmg-prod/images/phantom-scintilla-private-collection-0-1-66b50a5eddd44.jpg?crop=0.832xw:0.832xh;0.0849xw,0.168xh&resize=1200:*",
    desc: "סמל סטטוס יוקרתי, הכי קרוב למלוכה.",
    longDesc: `Rolls Royce Phantom הוא הסמל העליון ליוקרה ואלגנטיות. 
    כל פרט במכונית זו מיוצר בקפידה ומביא לידי ביטוי את האומנות של התעשייה הבריטית.
    עם מנוע עוצמתי, טכנולוגיות מתקדמות ופנים מפואר להפליא – זוהי המכונית לאלו שרוצים את הטוב ביותר בלבד.`,
    price: "₪2,500,000"
  },
  ghost: {
    id: 'ghost',
    name: "Ghost",
    img: "https://images.carexpert.com.au/resize/960/-/cms/v1/media/2024-10-rolls-royce-ghost-series-ii-edit-3x2-41.jpg",
    desc: "עיצוב נקי, מנוע עוצמתי – קלאסה אמיתית.",
    longDesc: `Rolls Royce Ghost משלבת עיצוב מודרני עם ביצועים עוצרי נשימה. 
    היא מציעה חווית נהיגה שקטה ומפנקת במיוחד, ומושקעת בטכנולוגיה מתקדמת שתגרום לך להרגיש כל נסיעה כנסיעה ראשונה.`,
    price: "₪2,000,000"
  },
  cullinan: {
    id: 'cullinan',
    name: "Cullinan",
    img: "https://www.topgear.com/sites/default/files/2024/05/Rolls_Royce_Cullinan_SII_%281%29.jpg?w=892&h=502",
    desc: "רכב שטח יוקרתי – לרדת לשטח עם סטייל של מיליארדר.",
    longDesc: `Rolls Royce Cullinan הוא רכב השטח הראשון של החברה, שמביא עימו את כל המותרות של רולס רויס גם לטריטוריה האקסטרימית. 
    עם ביצועים חזקים, נוחות שאין כמוה ויכולות שטח מרשימות, זהו הרכב לכל מי שמחפש יוקרה גם מחוץ לאספלט.`,
    price: "₪2,800,000"
  }
};